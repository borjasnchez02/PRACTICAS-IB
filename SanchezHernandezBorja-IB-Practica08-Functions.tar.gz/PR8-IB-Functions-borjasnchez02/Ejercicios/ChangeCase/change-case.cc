#include <iostream>
#include "conversor.h"

int main() {
  std::string cadena;
  std::cout << "Introduce una palabra sin espacios: ";
  std::cin >> cadena;
  std::cout << "Palabra original: " << cadena << std::endl;
  std::cout << "Palabra convertida: " << ConvertirCadena(cadena) << std::endl;
  return 0;
}
