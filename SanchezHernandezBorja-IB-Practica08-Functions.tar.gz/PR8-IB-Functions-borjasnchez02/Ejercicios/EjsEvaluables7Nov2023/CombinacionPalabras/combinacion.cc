/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * 
 * @file combinacion.cc 
 * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
 * @date 7 Nov 2023
 * @brief The current programe receive two strings in std::string format and return their combination, taking one letter from each alternately
 * @bug There are no known bugs
 */

#include <iostream>
#include <string>

std::string combinarCadenas(const std::string &cadena1, const std::string &cadena2) {
    std::string resultado = "";
    int longitud1 = cadena1.length();
    int longitud2 = cadena2.length();
    int minLongitud = std::min(longitud1, longitud2);

    for (int i = 0; i < minLongitud; i++) {
        resultado += cadena1[i];
        resultado += cadena2[i];
    }
    return resultado;
}

int main() {
    std::string cadena1, cadena2;

    std::cout << "Introduce la primera cadena: ";
    std::cin >> cadena1;

    std::cout << "Introduce la segunda cadena: ";
    std::cin >> cadena2;

    std::string resultado = combinarCadenas(cadena1, cadena2);

    std::cout << "La combinación de las cadenas es: " << resultado << std::endl;

    return 0;
}
