/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * 
 * @file AreaTriangle.cc
 * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
 * @date 7 Nov 2023
 * @brief
 * @bug There are no knowm bugs
*/

#include <iostream>
#include <cmath>

const double PI = M_PI; //define la constante utilizando M_PI de la libreria cmath  

double calcularAreaTrianguloEquilatero(double lado) { 
    double area = std::sin(PI / 3.0) * lado * lado / 2.0; //operación para calcular el area del trinagulo 
    return area;
}

int main() {
    double lado;
    
    std::cout << "Ingrese la longitud de un lado del triángulo equilátero: ";
    std::cin >> lado;

    
    if (lado > 0) { //verifica que el lado sea positivo
        double area = calcularAreaTrianguloEquilatero(lado);
        std::cout << "El área del triángulo equilátero es: " << area << std::endl;
    } else {
        std::cout << "El valor introducido no es válido. " << std::endl; //de lo contrario muestra mensaje de error
    }

    return 0;
}
