/**
 *  * Universidad de La Laguna
 *   * Escuela Superior de Ingeniería y Tecnología
 *    * Grado en Ingeniería Informática
 *     * Informática Básica
 *      * 
 *       * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
 *        * @date 4 Nov 2023
 *         * @brief The current program takes as input two natural numbers n and m
 *             such that n < m and generates a real random number r in the interval [n,m]
 *              * 
 *               */
#include <iostream>
#include <cstdlib> //biblioteca que proporciona funciones relacionadas con la generacion de numero aleatorio como "std::rand"
#include <ctime> //se utiliza para obtener la hora actual y se ua para inicializar la semilla del generador de numeros aleatorios 

double random_number(int n, int m) { //define la funcion en amarillo que toma dos numeros entero "n" y "m" como parametros y devuelve el numero real "double" generado aleatoriamente
    std::srand(std::time(nullptr)); //inicializa la semilla del generador std::rand. Asegura que los numeros generados sean diferentes cada vez que se ejecute el programa 
    double r = n + (m - n) * (static_cast<double>(std::rand()) / RAND_MAX); //genera un numero aleatorio "r" en el rango [n,m]. (static_cast... genera un valor aleatorio en el rango [0,1]
    return r; //devuelve el numero aleatorio generado 
}

int main() {
    int n, m;
    std::cout << "Ingrese dos números naturales n y m tales que n < m: ";
    std::cin >> n >> m;
    double r = random_number(n, m); //llama a la funcion random_number con los valores "n" y "m" y almacena el resultado en la variables "r"
    std::cout << "El número aleatorio generado es: " << r << std::endl;
    return 0;
}
