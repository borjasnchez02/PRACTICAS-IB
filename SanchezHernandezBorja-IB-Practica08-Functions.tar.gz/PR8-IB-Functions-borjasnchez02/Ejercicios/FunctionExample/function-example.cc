/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * 
 * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
 * @date 
 * @brief 
 *   
 */
#include <iostream>
#include <cmath>

double calcularG(double x, double y, double t) {
    double resultado = sqrt(2 * t - 4) / ((x * x) - (y * y)); // Realizamos el cálculo de la función g(x, y, z)
    return resultado;
}
int main() {
    double x, y, t; // Solicitamos al usuario que ingrese los valores de x, y y t
    std::cout << "Ingresa el valor de x: ";
    std::cin >> x;
    std::cout << "Ingresa el valor de y: ";
    std::cin >> y;
    std::cout << "Ingresa el valor de t: ";
    std::cin >> t;

    double resultado = calcularG(x, y, t); // Llamamos a la función calcularG con los valores ingresados
    std::cout << "El resultado de g(" << x << ", " << y << ", " << t << ") es: " << resultado << std::endl; // Mostramos el resultado
    return 0;
}
