/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * 
 * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
 * @date 4 Nov 2023
 * @brief The current program takes as input the lengths a, b, c of the sides
 * of a triangle and calculates its area using Heron´s Formula.
 * 
 */

#include <iostream>
#include <cmath>

double Area(double a, double b, double c) { // Función para calcular el área de un triángulo utilizando la Fórmula de Herón
    double s = (a + b + c) / 2.0;  // Semiperímetro
    double area = sqrt(s * (s - a) * (s - b) * (s - c)); // Fórmula de Herón
    return area;
}

bool IsAValidTriangle(double a, double b, double c) { // Función para verificar si los lados forman un triángulo válido
    return (a + b > c) && (a + c > b) && (b + c > a);
}

int main() {
    double a, b, c;
    std::cout << "Ingrese la longitud del lado a: ";  // Solicitar al usuario ingresar las longitudes de los lados
    std::cin >> a;
    std::cout << "Ingrese la longitud del lado b: ";
    std::cin >> b;
    std::cout << "Ingrese la longitud del lado c: ";
    std::cin >> c;

    if (IsAValidTriangle(a, b, c)) {  // Verificar si los lados forman un triángulo válido
        double area = Area(a, b, c);
        std::cout << "El área del triángulo es: " << area << std::endl;
    } else {
        std::cout << "Los lados no forman un triángulo válido." << std::endl;
    }

    return 0;
}
