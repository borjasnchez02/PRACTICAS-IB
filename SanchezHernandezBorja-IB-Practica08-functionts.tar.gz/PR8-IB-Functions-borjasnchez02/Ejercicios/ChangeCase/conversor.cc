#include "conversor.h"

std::string ConvertirCadena(std::string cadena) {
  for (int i = 0; i < cadena.length(); i++) {
    if (cadena[i] >= 'a' && cadena[i] <= 'z') {
      cadena[i] = toupper(cadena[i]);
    } else if (cadena[i] >= 'A' && cadena[i] <= 'Z') {
      cadena[i] = tolower(cadena[i]);
    }
  }
  return cadena;
}
