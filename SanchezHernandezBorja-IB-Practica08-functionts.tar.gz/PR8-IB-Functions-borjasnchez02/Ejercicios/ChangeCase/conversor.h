#include <string>

std::string ConvertirCadena(std::string cadena);
