 /**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Borja Sánchez Hernández alu0101578583@ull.edu.es
  * @date 7 Nov 2023
  * @brief 
  * @bug There are no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
 
#include <iostream>
#include <cmath>
 
double CircleLength(double radio) {
  double longitud = 2 * M_PI * radio;
  return longitud;
 }
 
double CircleArea(double radio) {
  double area = M_PI * (radio * radio);
  return area;
 }
 
 double ToroideVolume(double r1, double r2) {

  double radio_mayor;
  double radio_menor;
  double radio;
  if (r1 > r2) {
    radio_mayor = r1;
    radio_menor = r2;
    double toroide = CircleLength(radio_mayor) * CircleArea(radio_menor);
  return toroide;
  } else if (r1 == r2) {
      radio == r1;
    double toroide = CircleLength(radio) * CircleArea(radio);
  return toroide;
  } else {
    radio_mayor = r2;
    radio_menor = r1;
    double toroide = CircleLength(radio_mayor) * CircleArea(radio_menor);
  return toroide;
  }
}
  
 int main() {
  int r1, r2;
  std::cin >> r1 >> r2;
 
  double resultado = ToroideVolume(r1, r2);
  std::cout << resultado << std::endl;
  return 0;
}
 
